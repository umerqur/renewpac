=== All-in-One WP Migration ===
Contributors: yani.iliev, bangelov, pimjitsawang
Tags: db migration, migration, wordpress migration, db backup, db restore, website backup, website restore, website migration, website deploy, wordpress deploy, db backup, database export, database serialization, database find replace
Requires at least: 3.3
Tested up to: 4.7
Stable tag: 6.40
License: GPLv2 or later

All-in-One WP Migration is the only tool that you will ever need to migrate a WordPress site.

== Description ==
The plugin allows you to export your database, media files, plugins, and themes.
You can apply unlimited find/replace operations on your database and the plugin will also fix any serialization problems that occur during find/replace operations.

All in One WP Plugin is the first plugin to offer true mobile experience on WordPress versions 3.3 and up.

= Works on all hosting providers =
* The plugin does not depend on any extensions, making it compatible with all PHP hosting providers.
* The plugin exports and imports data in time chunks of 3 seconds each, which keeps the plugin below the max execution time that most providers set to 30 seconds.
* We have tested the plugin on the major Linux distributions, Mac OS X, and Microsoft Windows.

= Bypass all upload size restriction =
* We use chunks to import your data and that way we bypass any webserver upload size restrictions up to **512MB** - commercial version supports up to **5GB**.

= 0 Dependencies =
* The plugin does not require any php extensions and can work with PHP v5.2.

= Support for MySQL and MySQLi =
* No matter what php mysql driver your webserver ships with, we support it.

= Support WordPress v3.3 up to v4.x =
* We tested every WordPress version from `3.3` up to `4.x`.

= Supported hosting providers =
* Bluehost
* InMotion
* Web Hosting Hub
* Siteground
* Pagely
* Dreamhost
* Justhost
* GoDaddy
* WP Engine
* Site5
* 1&1
* Pantheon
* [See the full list of supported providers here](https://help.servmask.com/knowledgebase/supported-hosting-providers/)

= Migrate WordPress to most popular cloud services using our completely new extensions =
* [Unlimited](https://servmask.com/products/unlimited-extension)
* [Dropbox](https://servmask.com/products/dropbox-extension)
* [Multisite](https://servmask.com/products/multisite-extension)
* [FTP](https://servmask.com/products/ftp-extension)
* [Google Drive](https://servmask.com/products/google-drive-extension)
* [Amazon S3](https://servmask.com/products/amazon-s3-extension)
* [URL](https://servmask.com/products/url-extension)
* [OneDrive](https://servmask.com/products/onedrive-extension)
* [Box](https://servmask.com/products/box-extension)
* And many more to come

= Contact us =
* [Get free help from us here](https://servmask.com/help)
* [Report a bug or request a feature](https://servmask.com/help)
* [Find out more about us](https://servmask.com)

[youtube http://www.youtube.com/watch?v=BpWxCeUWBOk]

[youtube http://www.youtube.com/watch?v=mRp7qTFYKgs]

== Installation ==
1. Upload the `all-in-one-wp-migration` folder to the `/wp-content/plugins/` directory
1. Activate the All in One WP Migration plugin through the 'Plugins' menu in WordPress
1. Configure the plugin by going to the `Site Migration` menu that appears in your admin menu

== Screenshots ==
1. Mobile Export page
2. Mobile Import page
3. Plugin Menu

== Changelog ==
= 6.40 =
* Do not extract dropins files on import
* Fix an issue with large files on import
* Fix an issue with inactive plugins option in advanced settings on export
* Do not exclude active plugins in package.json and multisite.json on export
* Do not show "Resolving URL address..." on export/import
* Add separate action hook in advanced settings called "ai1wm_export_advanced_settings" to allow custom checkbox options on export

= 6.39 =
* Add support for MariaDB
* Do not include package.json, multisite.json, blogs.json, database.sql and filemap.list files on export
* Fix an issue with unpacking archive on import
* Fix an issue with inactivated plugins on import
* Remove HTTP Basic authentication from Backups page

= 6.38 =
* Add support for HyperDB plugin
* Add support for RevSlider plugin
* Check available disk space during export/import
* Support very restricted hosting environments
* Add wpress mime-type to web.config when the server is IIS
* Switch to AJAX from cURL on export/import
* Respect WordPress constants FS_CHMOD_DIR and FS_CHMOD_FILE on import
* Fix an issue related to generating archive and folder names
* Fix an issue related to CSS styles on export page
* Remove misleading available disk space information on "Backups" page

= 5.56 =
* Fix an issue with WP_Hook class introcuded in WP 4.7

= 5.55 =
* Fix an issue with resolving URL on export/import when using non-blocking streams client

= 5.54 =
* Fix an issue with resolving URL on export/import

= 5.53 =
* Send HTTP basic authorization header on upload (fetch method)
* Add Accept-Encoding, Accept-Charset and Accept-Language on export/import
* Do not replace already replaced values on database import/export
* Set silent mode when activating sidewide plugins
* Replace old media style URLs with the new media style URLs on database import
* Replace user_level and capabilities user meta keys if tables have empty prefix on export
* Create separate action for extracting must-use plugins
* Add option "Do not export must-use plugins" in advanced settings
* Fix an issue with SSL that produces "Unable to resolve URL..."

= 5.52 =
* Simplify the text on import page
* Fix an issue with special characters on export and import
* Fix an issue with export and import of large files

= 5.51 =
* Add support for utf8mb4_unicode_520_ci database collation

= 5.50 =
* Improve database export process
* Simplify export and import cron
* Fix an issue with export and import progress status

= 5.49 =
* Test plugin up to WordPress 4.6

= 5.48 =
* Improve support for large databases on export
* Add support for Box cloud storage
* Fix an issue with status on export/import
* Fix an issue with asynchronous requests on export/import

= 5.47 =
* Fix an issue with incorrect file size on export

= 5.46 =
* Add "Restore from Backups" video in readme file
* Display message if backups are inaccessible

= 5.45 =
* Fix an issue with blogs.dir path replacement

= 5.44 =
* Add "Do not replace email domain" option in advanced settings
* Add "ai1wm_exclude_content_from_export" WordPress hook on export
* Add HTML5 uploader

= 5.43 =
* Fix an issue when archiving dynamic files on export
* Support custom upload path for multisites
* Add support for various cache plugins

= 5.42 =
* Catch E_PARSE error on mu-plugins import
* Fix an issue with stop export that doesn't clean up the storage directory
* Initialize new cache instead of flushing the existing one on import/export

= 5.41 =
* Fix an issue when replacing serialized values on import
* List files in chunks
* Convert svg images to png
* Check if backups are readable before displaying them on "Backups" page
* Display version incompatibility notification on export/import/restore screen
* Fix double port issue on Bitnami
* Fix an issue on multisite export with cloud extensions

= 5.40 =
* Test plugin up to WordPress 4.5

= 5.39 =
* Fix a bug in uploads path replacement

= 5.38 =
* Deactivate mu-plugins if fatal error appears on import

= 5.37 =
* Validate the archive before import

= 5.36 =
* Add OneDrive to readme.txt
* Fix a typo on import

= 5.35 =
* Add OneDrive to export/import pages
* Fix a bug when WordPress was used without a db prefix
* Fix a problem when downloading wpress files
* Improve the log system

= 4.19 =
* Fixed an issue with options cache

= 4.18 =
* Fixed an issue with large media files
* Fixed an issue with status file being cached

= 4.17 =
* Set "Tested up to" WordPress 4.4

= 4.16 =
* Fix an issue with the transport layer on export/import

= 4.15 =
* Fix an issue with resovling mechanism on export/import

= 4.14 =
* Fix an issue with database import

= 4.13 =
* Add new mechanism for resolving HTTP requests

= 4.12 =
* Fix an issue with Google Drive extension

= 4.11 =
* Fix content filters on export

= 4.10 =
* Add HTTPS URL replacement
* Fix an issue when PDO is not available

= 4.6 =
* Fix an issue when the plugin was getting stuck on "Done creating an empty archive"
* Fix an issue when the plugin was getting stuck during import

= 4.3 =
* Add URL extension support
* Filter "mu-plugins" directory if "Do not export plugins (files)" is checked
* Fix utf8mb4 issue
* Fix translation issue

= 4.2 =
* Fix .wpress.bin format

= 4.1 =
* Add port to the host header on export/import
* Rename .wpress file to .wpress.bin file

= 4.0 =
* Fix file permission checks

= 3.9 =
* Fix could not resolve domain name on export/import

= 3.8 =
* Fix undefined method on Backups page if PHP version is < 5.3.6

= 3.7 =
* Add IPv6 support on export/import

= 3.6 =
* Fixed undefined constant warnings

= 3.5 =
* Exclude core plugin and extensions on export if they have custom names

= 3.4 =
* Made export/import processes more reliable
* Allow the plugin to work with non-default name
* Preserve backups during plugin updates
* Improved find & replace functionality on the serialized data
* Removed backup file name restrictions

= 3.3 =
* Fixed a bug when retrieving export/import status progress
* Fixed a bug when database encoding utf8mb4_unicode_ci is not available

= 3.2.2 =
* Fixed plugin incompatibility during export/import that was reporting that the process could not be started

= 3.2.1 =
* Added username/password settings for WordPress sites behind HTTP basic authentication
* Fixed a bug when exporting/importing without public DNS record
* Fixed a bug when exporting/importing media files

= 3.2.0 =
* Added advanced settings on export page

= 3.1.1 =
* Fixed secret key issue on upgrade of the plugin

= 3.0.0 =
* Added export to File, [Dropbox](https://servmask.com/products/dropbox-extension), [Amazon S3](https://servmask.com/products/amazon-s3-extension), [Google Drive](https://servmask.com/products/google-drive-extension)
* Added import from File, [Dropbox](https://servmask.com/products/dropbox-extension), [Amazon S3](https://servmask.com/products/amazon-s3-extension), [Google Drive](https://servmask.com/products/google-drive-extension)
* Implemented our own archiving format that reduces export and import by a factor of 10
* One-click export with the new simplified export page
* Improved upload functionality with auto-recognizing chunk size on import
* New **Backups** page for storing all WordPress site exports
* Easy restore WordPress site from **Backups** page
* Monitoring availability of the disk space on the server
* Both export and import happen in time chunks of 3 seconds
* Plugin works behind HTTP basic authentication

= 2.0.4 =
* Updated readme to reflect that the plugin is not multisite compatible

= 2.0.3 =
* Fixed a security issue while importing site using regular users

= 2.0.2 =
* Added support for WordPress v4.0

= 2.0.1 =
* Fixed a bug when all user permissions are lost on import

= 2.0.0 =
* Added support for migration of WordPress in Network Mode (Multi Site)
* New improved UI and UX
* New improved language translations on the menu items and help texts
* Better error handling and notifications
* Fixed a bug while exporting comments and associated comments meta data
* Fixed a bug while using find/replace functionality
* Fixed a bug with storage directory permissions and search indexation

= 1.9.2 =
* Added PHP <= v5.2.7 compatibility

= 1.9.1 =
* Fixed an issue with earlier versions of PHP

= 1.9.0 =
* New improved design on the export/import page
* Added an option for gathering user experience statistics
* Added a message box with important notifications about the plugin
* Fixed a bug while exporting database with multiple WordPress sites
* Fixed a bug while exporting database with table constraints
* Fixed a bug with auto recognizing zip archiver

= 1.8.1 =
* Added "Get Support" link in the plugin list page
* Removed "All in One WP Migration Beta" link from the readme file

= 1.8.0 =
* Added support for dynamically recognizing Site URL and Home URL on the import page
* Fixed a bug when maximum uploaded size is exceeded
* Fixed a bug while exporting big database tables

= 1.7.2 =
* Added support for automatically switching database adapters for better performance and optimization
* Fixed a bug while using host:port syntax with MySQL PDO
* Fixed a bug while using find/replace functionality

= 1.7.1 =
* Fixed a bug while exporting WordPress plugins directory

= 1.7.0 =
* Added storage layer to avoid permission issues with OS's directory used for temporary storage
* Added additional checks to verify the consistency of the imported archive
* Fixed a bug that caused the database to be exported without data
* Removed unused variables from package.json file

= 1.6.0 =
* Added additional check for directory's permissions
* Added additional check for output buffering when exporting a file
* Fixed a bug when the archive was exported or imported with old version of Zlib library
* Fixed a bug with permalinks and flushing the rules

= 1.5.0 =
* Added support for additional errors and exceptions handling
* Added support for reporting a problem in better and easier way
* Improved support process in ZenDesk system for faster response time
* Fixed typos on the import page. Thanks to Terry Heenan

= 1.4.0 =
* Added a Twitter and Facebook share buttons to the sidebar on import and export pages

= 1.3.1 =
* Fixed a bug when the user was unable to import site archive
* Optimized and speeded up import process

= 1.3.0 =
* Added support for mysql connection to happen over sockets or TCP
* Added support for Windows OS and fully tested the plugin on IIS
* Added support for limited memory_limit - 1MB - The plugin now requires only 1MB to operate properly
* Added support for multisite
* Used mysql_unbuffered_query instead of mysql_query to overcome any memory problems
* Fixed a deprecated warning for mysql_pconnect when php 5.5 and above is used
* Fixed memory_limit problem with PCLZIP library
* Fixed a bug when the archive is exported with zero size when using PCLZIP
* Fixed a bug when the archive was exported broken on some servers
* Fixed a deprecated usage of preg_replace \e in php v5.5 and above

= 1.2.1 =
* Fixed an issue when HTTP Error was shown on some hosts after import, credit to Michael Simon
* Fixed an issue when exporting databases with different prefix than wp_, credit to najtrox
* Fixed an issue when PDO is avalable but mysql driver for PDO is not, credit to Jaydesain69
* Deleted a plugin specific option when uninstalling the plugin (clean after itself)
* Support is done via Zendesk
* Included WP Version and Plugin version in the feedback form

= 1.2.0 =
* Increased upload limit of files from 128MB to 512MB
* Used ZipArchive with fallback to PclZip (a few users notified us that they don’t have ZipArchive enabled on their servers)
* Used PDO with fallback to mysql (a few users notified us that they dont have PDO enabled on their servers, mysql is deprecated as of PHP v5.5 but we are supporting PHP v5.2.17)
* Supported PHP v5.2.17 and WordPress v3.3 and above
* Fixed a bug during export that causes plugins to not be exported on some hosts (the problem that you are experiencing)

= 1.1.0 =
* Importing files using chunks to overcome any webserver upload size restriction
* Fixed a bug where HTTP code error was shown to some users

= 1.0.0 =
* Export database as SQL file
* Export media files
* Export themes files
* Export installed plugins
* Unlimited find/replace actions
* Option to exclude spam comments
* Option to apply find/replace to GUIDs
* Option to exclude post revisions
* Option to exclude tables data
